#!/bin/bash

python lietorch/run_tests.py
